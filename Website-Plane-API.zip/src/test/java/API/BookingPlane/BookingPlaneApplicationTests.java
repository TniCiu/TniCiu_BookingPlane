package API.BookingPlane;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class BookingPlaneApplicationTests {

	@Test
	void contextLoads() {
	}

}
